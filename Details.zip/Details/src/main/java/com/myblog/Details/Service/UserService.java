package com.myblog.Details.Service;

import java.util.List;

import com.myblog.Details.Entity.User;
import com.myblog.Details.exception.NotFound;

public interface UserService {

	User create(User user);
	List<User> getAll();
	User getById(int id);
	String deleteById(int id) throws NotFound;
	
}
