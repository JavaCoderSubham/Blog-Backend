package com.myblog.Details.Service.ServiceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.myblog.Details.Entity.User;
import com.myblog.Details.Repository.UserRepository;
import com.myblog.Details.Service.UserService;
import com.myblog.Details.exception.NotFound;

@Service
public class UserServiceImpl implements UserService{
	
	
	
	@Autowired
	UserRepository userRepository;

	@Override
	public User create(User user) {
		
		return userRepository.save(user);
	}

	@Override
	public List<User> getAll() {
		
		return userRepository.findAll();
	}

	@Override
	public String deleteById(int id) throws NotFound {
		if(userRepository.findById(id).isPresent()) {
			userRepository.deleteById(id);
			return "user deleted";
		}else {
			throw new NotFound("User  Not Found with id: "+id);
		}
	}

	@Override
	public User getById(int id) {
		 Optional<User > optional = userRepository.findById(id);
		return optional.get();
	}

}
