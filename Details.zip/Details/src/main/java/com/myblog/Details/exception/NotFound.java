package com.myblog.Details.exception;

public class NotFound extends Exception{
	
	public NotFound(String msg) {
		super(msg);
	}

}
