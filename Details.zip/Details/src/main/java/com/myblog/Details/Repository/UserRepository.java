package com.myblog.Details.Repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.myblog.Details.Entity.User;

public interface UserRepository extends MongoRepository<User, Integer>{
	

}
